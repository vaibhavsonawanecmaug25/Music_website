package com.music.model;

public enum User_role {
	 USER , ADMIN;
		

}
