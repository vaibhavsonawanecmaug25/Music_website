package com.music.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ArtistDto {
private Long artistId;
  private String name;
  private String bio;
	}


